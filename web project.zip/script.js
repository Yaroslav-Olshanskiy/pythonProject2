function hide_garland(){
	document.getElementById('garland').style.opacity=0;
}

